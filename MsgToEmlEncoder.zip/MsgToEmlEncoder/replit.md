# MSG to EML Converter

## Overview
A web-based tool for converting Outlook .msg files to standard .eml (RFC 822) format. Built with Flask and Python, this application preserves all email properties including embedded emails and attachments.

## Purpose
Convert Microsoft Outlook .msg files to the universal .eml email format while maintaining:
- Complete email headers and metadata
- Inner/embedded email messages
- All file attachments
- HTML and plain text body content

## Current State
**Status**: Initial MVP complete and running
**Date**: November 21, 2025

## Recent Changes
- November 21, 2025: Initial project setup
  - Installed Flask and extract-msg dependencies
  - Created Flask web application with file upload/download
  - Implemented .msg to .eml conversion with inner email support
  - Built responsive web interface with drag-and-drop upload
  - Configured Flask workflow on port 5000

## Project Architecture

### Technology Stack
- **Backend**: Python 3.11, Flask 3.0.0
- **MSG Parser**: extract-msg 0.48.7
- **Email Generation**: Python email module (MIME)
- **Frontend**: Vanilla HTML/CSS/JavaScript

### File Structure
```
.
├── app.py                  # Flask application with routes
├── converter.py            # MSG to EML conversion logic
├── templates/
│   └── index.html         # Web interface
├── requirements.txt       # Python dependencies
├── uploads/               # Temporary upload folder
└── output/                # Temporary converted files folder
```

### Key Features
1. **File Upload**: Drag-and-drop or click to upload .msg files (max 50MB)
2. **Conversion Engine**: Parses .msg using extract-msg and converts to RFC 822 .eml format
3. **Inner Email Support**: Detects and preserves embedded emails as MIME message attachments
4. **Attachment Preservation**: Maintains all file attachments with proper encoding
5. **Auto-cleanup**: Removes temporary files after download
6. **Error Handling**: Comprehensive error reporting for failed conversions

### Conversion Logic
The `converter.py` module handles the conversion process:
- Extracts message properties (sender, recipients, subject, date)
- Converts body to MIME multipart (plain text and HTML)
- Recursively processes embedded .msg attachments as inner emails
- Encodes regular file attachments as base64
- Generates RFC 822 compliant .eml output

### API Endpoints
- `GET /` - Main upload interface
- `POST /convert` - Upload and convert .msg file
- `GET /download/<filename>` - Download converted .eml file

## Dependencies
- Flask==3.0.0 - Web framework
- extract-msg==0.48.7 - Parse .msg files
- Werkzeug==3.0.1 - WSGI utilities

## User Preferences
None specified yet.

## Notes
- Files are automatically deleted after download to prevent storage buildup
- Maximum upload size is 50MB
- Only .msg files are accepted for conversion
