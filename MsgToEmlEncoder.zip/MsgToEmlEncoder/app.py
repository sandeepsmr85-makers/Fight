import os
from flask import Flask, request, render_template, send_file, jsonify
from werkzeug.utils import secure_filename
from converter import convert_msg_to_eml
import traceback

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['OUTPUT_FOLDER'] = 'output'

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)

ALLOWED_EXTENSIONS = {'msg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/convert', methods=['POST'])
def convert():
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'Only .msg files are allowed'}), 400
    
    try:
        filename = secure_filename(file.filename or '')
        msg_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(msg_path)
        
        eml_filename = filename.rsplit('.', 1)[0] + '.eml'
        eml_path = os.path.join(app.config['OUTPUT_FOLDER'], eml_filename)
        
        convert_msg_to_eml(msg_path, eml_path)
        
        os.remove(msg_path)
        
        return jsonify({
            'success': True,
            'filename': eml_filename,
            'message': 'Conversion successful! Inner emails and attachments preserved.'
        })
    
    except Exception as e:
        error_trace = traceback.format_exc()
        print(f"Conversion error: {error_trace}")
        return jsonify({'error': f'Conversion failed: {str(e)}'}), 500

@app.route('/download/<filename>')
def download(filename):
    try:
        filepath = os.path.join(app.config['OUTPUT_FOLDER'], secure_filename(filename))
        if not os.path.exists(filepath):
            return jsonify({'error': 'File not found'}), 404
        
        response = send_file(
            filepath,
            as_attachment=True,
            download_name=filename,
            mimetype='message/rfc822'
        )
        
        @response.call_on_close
        def cleanup():
            try:
                if os.path.exists(filepath):
                    os.remove(filepath)
            except Exception as e:
                print(f"Cleanup error: {e}")
        
        return response
    
    except Exception as e:
        print(f"Download error: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
