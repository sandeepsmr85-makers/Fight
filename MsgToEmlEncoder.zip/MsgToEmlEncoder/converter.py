import extract_msg
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.message import MIMEMessage
from email import encoders
from email.utils import formataddr, formatdate
import os
import tempfile

def convert_msg_to_eml(msg_path, eml_path):
    """
    Convert a .msg file to .eml format, preserving inner emails and attachments.
    """
    msg = extract_msg.Message(msg_path)
    
    email_msg = create_mime_message(msg)
    
    with open(eml_path, 'w', encoding='utf-8') as eml_file:
        eml_file.write(email_msg.as_string())
    
    msg.close()

def create_mime_message(msg):
    """
    Create a MIME message from an extract_msg.Message object.
    Handles inner emails and attachments.
    """
    mime_msg = MIMEMultipart()
    
    sender = msg.sender or ''
    mime_msg['From'] = formataddr((msg.senderName or '', sender))
    mime_msg['To'] = msg.to or ''
    mime_msg['Subject'] = msg.subject or '(No Subject)'
    mime_msg['Date'] = formatdate(localtime=True)
    
    if msg.cc:
        mime_msg['Cc'] = msg.cc
    if msg.date:
        try:
            mime_msg['Date'] = msg.date.strftime('%a, %d %b %Y %H:%M:%S %z')
        except:
            pass
    
    body = msg.body or ''
    if body:
        mime_msg.attach(MIMEText(body, 'plain', 'utf-8'))
    
    html_body = msg.htmlBody
    if html_body:
        mime_msg.attach(MIMEText(html_body, 'html', 'utf-8'))
    
    if msg.attachments:
        for attachment in msg.attachments:
            try:
                filename = getattr(attachment, 'longFilename', None) or \
                          getattr(attachment, 'shortFilename', None) or \
                          'attachment'
                
                is_msg = False
                if hasattr(attachment, 'type'):
                    try:
                        from extract_msg.enums import AttachmentType
                        is_msg = attachment.type == AttachmentType.MSG
                    except:
                        is_msg = filename.lower().endswith('.msg')
                else:
                    is_msg = filename.lower().endswith('.msg')
                
                if is_msg:
                    try:
                        attachment_data = attachment.data
                        if isinstance(attachment_data, bytes):
                            with tempfile.NamedTemporaryFile(delete=False, suffix='.msg') as tmp_file:
                                tmp_file.write(attachment_data)
                                tmp_path = tmp_file.name
                            
                            try:
                                inner_msg = extract_msg.Message(tmp_path)
                                inner_mime = create_mime_message(inner_msg)
                                inner_msg.close()
                                
                                msg_attachment = MIMEMessage(inner_mime)
                                eml_filename = filename.rsplit('.', 1)[0] + '.eml' if '.' in filename else filename + '.eml'
                                msg_attachment.add_header('Content-Disposition', 'attachment', 
                                                        filename=eml_filename)
                                msg_attachment.set_type('message/rfc822')
                                mime_msg.attach(msg_attachment)
                                print(f"Successfully converted embedded email: {filename}")
                            finally:
                                os.unlink(tmp_path)
                        else:
                            attach_regular_file(mime_msg, attachment)
                    except Exception as e:
                        print(f"Warning: Could not process embedded MSG {filename}: {e}")
                        attach_regular_file(mime_msg, attachment)
                else:
                    attach_regular_file(mime_msg, attachment)
            except Exception as e:
                print(f"Warning: Could not process attachment: {e}")
                continue
    
    return mime_msg

def attach_regular_file(mime_msg, attachment):
    """
    Attach a regular file (non-email) to the MIME message.
    """
    try:
        filename = getattr(attachment, 'longFilename', None) or \
                  getattr(attachment, 'shortFilename', None) or \
                  'attachment'
        
        data = attachment.data
        if isinstance(data, bytes):
            file_data = data
        elif hasattr(data, 'read'):
            file_data = data.read()
        else:
            file_data = str(data).encode('utf-8')
        
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(file_data)
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename="{filename}"')
        
        mime_msg.attach(part)
    
    except Exception as e:
        print(f"Error attaching file: {e}")
        raise
